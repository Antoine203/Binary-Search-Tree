//
//  main.cpp
//  binarySearchTree
//
//  Created by Antoine Jermaine Smith Jr. on 10/21/20.
//

#include <iostream>
#include "binaryTree.cpp"
using namespace std;

int main(int argc, const char * argv[]) {
    TreeType<char> charTree;
    charTree.addItem('D');
    charTree.addItem('F');
    charTree.addItem('C');
    charTree.addItem('A');
    charTree.addItem('B');
    charTree.addItem('E');
    charTree.printTree();
    return 0;
}
